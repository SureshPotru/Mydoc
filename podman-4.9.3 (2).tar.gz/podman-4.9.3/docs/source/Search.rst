.. include:: includes.rst

Search
==================================

.. raw:: html

    <p>
    From here you can search these documents. Enter your search
    words into the box below and click "search". Note that the search
    function will automatically search for all of the words. Pages
    containing fewer words won't appear in the result list.
    </p>
    <form action="/en/latest/search.html" method="get" _lpchecked="1">
    <input type="text" name="q" value="">
    <input type="submit" value="search">
    <span id="search-progress" style="padding-left: 10px"></span>
    </form>
