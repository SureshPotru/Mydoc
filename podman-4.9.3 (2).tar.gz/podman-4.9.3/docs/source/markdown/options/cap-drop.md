####> This option file is used in:
####>   podman create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--cap-drop**=*capability*

Drop Linux capabilities.
