####> This option file is used in:
####>   podman create, pod clone, pod create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--label**, **-l**=*key=value*

Add metadata to a <<container|pod>>.
