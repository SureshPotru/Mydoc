####> This option file is used in:
####>   podman create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--no-healthcheck**

Disable any defined healthchecks for container.
