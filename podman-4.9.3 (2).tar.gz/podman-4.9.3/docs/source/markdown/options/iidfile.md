####> This option file is used in:
####>   podman build, farm build
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--iidfile**=*ImageIDfile*

Write the built image's ID to the file.  When `--platform` is specified more than once, attempting to use this option triggers an error.
