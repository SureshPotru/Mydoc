####> This option file is used in:
####>   podman pod stats, stats
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--no-stream**

Disable streaming <<|pod >>stats and only pull the first result, default setting is false
