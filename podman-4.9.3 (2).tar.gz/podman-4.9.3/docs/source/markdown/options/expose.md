####> This option file is used in:
####>   podman create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--expose**=*port*

Expose a port, or a range of ports (e.g. **--expose=3300-3310**) to set up port redirection
on the host system.
