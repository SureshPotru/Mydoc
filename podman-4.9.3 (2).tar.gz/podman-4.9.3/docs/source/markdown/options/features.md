####> This option file is used in:
####>   podman manifest add, manifest annotate
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--features**

Specify the features list which the list or index records as requirements for
the image.  This option is rarely used.
