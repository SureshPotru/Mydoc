####> This option file is used in:
####>   podman build, create, farm build, pod create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--add-host**=*host:ip*

Add a custom host-to-IP mapping (host:ip)

Add a line to /etc/hosts. The format is hostname:ip. The **--add-host**
option can be set multiple times. Conflicts with the **--no-hosts** option.
