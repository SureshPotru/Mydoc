####> This option file is used in:
####>   podman pod rm, pod start, pod stop
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--pod-id-file**=*file*

Read pod ID from the specified *file* and <<subcommand>> the pod. Can be specified multiple times.
