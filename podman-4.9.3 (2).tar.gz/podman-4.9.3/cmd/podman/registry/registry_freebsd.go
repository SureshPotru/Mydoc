package registry

// DefaultRootAPIPath is the default path of the REST socket
const DefaultRootAPIPath = "/var/run/podman/podman.sock"
