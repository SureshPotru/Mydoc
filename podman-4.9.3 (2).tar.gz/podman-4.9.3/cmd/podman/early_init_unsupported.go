//go:build !linux && !darwin
// +build !linux,!darwin

package main

func earlyInitHook() {
}
